Welcome to Laticis Imagery!

Thank you for choosing to support my work by either purchasing or downloading one of my products.
I genuinely hope you find it enjoyable to use. Your feedback, whether positive or negative,
is immensely valuable to me as it aids in the continuous development and improvement of my content.

Usage Rights:
By acquiring or downloading this product, you are granted a non-exclusive, worldwide, royalty-free license
to utilize the supplied content, encompassing objects, textures, and any accompanying digital materials, for
both commercial and non-commercial purposes. This license permits you to integrate the product seamlessly
into your projects, such as renders, animations, illustrations, graphic designs, websites, applications,
videos, and any other digital or physical media. Furthermore, you have the freedom to modify, adapt, or
customize the product to suit your specific project requirements, including resizing, recoloring,
retexturing, or making any other alterations necessary for optimal integration.

Prohibited Actions:
To uphold the copyright and intellectual property rights associated with the supplied product,
it is strictly prohibited to engage in the following actions:

Copying, reproducing, or distributing the content without obtaining prior written permission.
Selling, licensing, renting, or leasing the product as a standalone item or as part of another
product without obtaining prior written permission.
Modifying, altering, or adapting the product in a manner that exceeds the scope of the granted
license without obtaining prior written permission.

Enforcement:
In the event of copyright infringement or unauthorized use of the supplied product, Adriano Di Pierro and
its Licensors reserve the right to take appropriate legal actions to safeguard their rights.
This may involve pursuing injunctive relief, seeking damages, or exercising any other remedies available
under applicable laws. I kindly request that you respect the copyright and intellectual property rights
associated with the supplied product. If you have any questions or require permission for specific usages
beyond the scope of this license, please contact me via email at ady@laticisimagery.com.

Commercial Projects:
For those intending to employ this product for commercial projects, please reach out to me via email at
ady@laticisimagery.com to initiate a discussion regarding the details.

Copyright Notice:
All contents provided in this package, including objects, textures, accompanying digital files, and any
additional materials, are the intellectual property of Adriano Di Pierro and its Licensors.
These contents are safeguarded by copyright laws and international treaty provisions.
Unauthorized use, reproduction, or distribution of the contents, either in whole or in part, is strictly prohibited.

Ownership:
Adriano Di Pierro and its Licensors retain complete ownership and all associated rights to the supplied product,
including objects, textures, and any accompanying digital content. This ownership encompasses all intellectual
property rights, including but not limited to copyright, trademarks, and any other relevant rights.

Credit to Other Contributors:
Merchant Resources: N/A (Not applicable)
Products Used: N/A (Not applicable)
Crediting Others: N/A (Not applicable)

--------------------------------------------------------------------------------------------------------------

INSTALLATION:

Run Winzip or alternative Zip-program to unpack the files.
Manually place or drag contents of folder into your specified DAZ Studio Content/Runtime folder.

--------------------------------------------------------------------------------------------------------------


Thanks and Happy Rendering :) 

Adriano Di Pierro
Laticis Imagery
